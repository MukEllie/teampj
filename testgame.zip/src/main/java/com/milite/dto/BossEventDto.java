package com.milite.dto;

import lombok.Data;

@Data
public class BossEventDto {
	private int be_id;
	private String be_name;
	private String be_session;
	private int MonsterID;
}