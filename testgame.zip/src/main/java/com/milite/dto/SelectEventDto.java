package com.milite.dto;

import lombok.Data;

@Data
public class SelectEventDto {
	private int se_id;
	private String se_name;
	private String se_session;
}