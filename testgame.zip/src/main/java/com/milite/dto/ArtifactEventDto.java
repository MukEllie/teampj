package com.milite.dto;

import lombok.Data;

@Data
public class ArtifactEventDto {
	private int ae_id;
	private String ae_name;
	private String ae_session;
}