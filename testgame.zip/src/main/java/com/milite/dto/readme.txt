각 폴더는 기존 전투쪽 testgame 내 같은 이름의 폴더에 복붙하면 적용 완


기존 testgame에서 수정된 파일:
CharacterStatusMapper.xml의 getPlayerInfo 파트 전체 수정
CharacterStatusMapper.java의 getPlayerInfo에서 Player를 @Param("PlayerID")로 수정